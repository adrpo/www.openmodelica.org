/* Header file ModelicaRead.h for ModelicaRead */
//double ModelicaRead();
double ModelicaRead(const char*,double);
