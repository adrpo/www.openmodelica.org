/* Header file TimerFunction.h for TimerFunction */
double getRealTime(double);
double initTime(double);

