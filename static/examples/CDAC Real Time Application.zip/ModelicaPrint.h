/* Header file ModelicaPrint.h for ModelicaPrint function */
//double ModelicaPrint(double);

double ModelicaPrint(const char*,double);
